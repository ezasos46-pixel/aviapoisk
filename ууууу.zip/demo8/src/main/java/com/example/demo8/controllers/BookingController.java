package com.example.demo8.controllers;

import com.example.demo8.models.*;
import com.example.demo8.services.SupabaseClient;
import com.example.demo8.utils.SessionManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;

public class BookingController {
    @FXML private VBox summaryBox;
    @FXML private VBox summaryContent;
    @FXML private Label totalPriceLabel;
    @FXML private VBox passengersForms;
    @FXML private TextField cardNumber;
    
    public void initialize() {
        // Форматирование номера карты
        cardNumber.textProperty().addListener((observable, oldValue, newValue) -> {
            String digits = newValue.replaceAll("\\D", "");
            if (digits.length() > 16) {
                digits = digits.substring(0, 16);
            }
            StringBuilder formatted = new StringBuilder();
            for (int i = 0; i < digits.length(); i++) {
                if (i > 0 && i % 4 == 0) {
                    formatted.append(" ");
                }
                formatted.append(digits.charAt(i));
            }
            if (!formatted.toString().equals(newValue)) {
                cardNumber.setText(formatted.toString());
            }
        });
        
        // Форматирование срока действия
        cardExpiry.textProperty().addListener((observable, oldValue, newValue) -> {
            String digits = newValue.replaceAll("\\D", "");
            if (digits.length() > 4) {
                digits = digits.substring(0, 4);
            }
            if (digits.length() >= 2) {
                String formatted = digits.substring(0, 2) + "/" + (digits.length() > 2 ? digits.substring(2) : "");
                if (!formatted.equals(newValue)) {
                    cardExpiry.setText(formatted);
                }
            }
        });
        
        // Ограничение CVV
        cardCVV.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                cardCVV.setText(newValue.replaceAll("\\D", ""));
            }
            if (cardCVV.getText().length() > 3) {
                cardCVV.setText(cardCVV.getText().substring(0, 3));
            }
        });
    }
    @FXML private TextField cardExpiry;
    @FXML private TextField cardCVV;
    
    private Flight flight;
    private RoundTrip roundTrip;
    private SearchParams searchParams;
    private SupabaseClient supabaseClient;
    private List<PassengerForm> passengerFormList;
    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    
    private static final Pattern NAME_PATTERN = Pattern.compile("^[А-Яа-яA-Za-z\\s]+$");
    private static final Pattern DOCUMENT_PATTERN = Pattern.compile("^\\d{10}$");
    private static final Pattern CARD_PATTERN = Pattern.compile("^\\d{16}$");
    private static final Pattern CVV_PATTERN = Pattern.compile("^\\d{3}$");
    private static final Pattern EXPIRY_PATTERN = Pattern.compile("^(0[1-9]|1[0-2])/(\\d{2})$");
    
    public void setFlight(Flight flight) {
        this.flight = flight;
        this.roundTrip = new RoundTrip(flight, null);
    }
    
    public void setRoundTrip(RoundTrip roundTrip) {
        this.roundTrip = roundTrip;
        if (roundTrip != null && roundTrip.getOutboundFlight() != null) {
            this.flight = roundTrip.getOutboundFlight();
        }
    }
    
    public void setSearchParams(SearchParams searchParams) {
        this.searchParams = searchParams;
        supabaseClient = new SupabaseClient();
        passengerFormList = new ArrayList<>();
        initializeForms();
        updateSummary();
    }
    
    private void initializeForms() {
        passengersForms.getChildren().clear();
        int totalPassengers = searchParams.getTotalPassengers();
        
        for (int i = 0; i < totalPassengers; i++) {
            PassengerForm form = new PassengerForm(i + 1);
            passengersForms.getChildren().add(form.getContainer());
            passengerFormList.add(form);
        }
    }
    
    private void updateSummary() {
        summaryContent.getChildren().clear();
        
        if (roundTrip == null || roundTrip.getOutboundFlight() == null) {
            return;
        }
        
        Flight outbound = roundTrip.getOutboundFlight();
        Flight returnFlight = roundTrip.getReturnFlight();
        
        // Рейс туда
        Label outboundTitle = new Label("РЕЙС ТУДА:");
        outboundTitle.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");
        summaryContent.getChildren().add(outboundTitle);
        
        Label routeLabel = new Label("Маршрут: " + outbound.getFromCityName() + " → " + outbound.getToCityName());
        routeLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
        summaryContent.getChildren().add(routeLabel);
        
        Label dateLabel = new Label("Дата вылета: " + outbound.getDepartureTime().format(dateFormatter));
        dateLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
        summaryContent.getChildren().add(dateLabel);
        
        Label flightLabel = new Label("Рейс: " + outbound.getAirlineName() + " " + outbound.getFlightNumber());
        flightLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
        summaryContent.getChildren().add(flightLabel);
        
        Label timeLabel = new Label("Время: " + outbound.getDepartureTime().format(timeFormatter) + " - " + outbound.getArrivalTime().format(timeFormatter));
        timeLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
        summaryContent.getChildren().add(timeLabel);
        
        // Рейс обратно (если есть)
        if (returnFlight != null) {
            Label separator = new Label("─────────────────");
            separator.setStyle("-fx-text-fill: white; -fx-font-size: 12px; -fx-padding: 5 0;");
            summaryContent.getChildren().add(separator);
            
            Label returnTitle = new Label("РЕЙС ОБРАТНО:");
            returnTitle.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");
            summaryContent.getChildren().add(returnTitle);
            
            Label returnRouteLabel = new Label("Маршрут: " + returnFlight.getFromCityName() + " → " + returnFlight.getToCityName());
            returnRouteLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
            summaryContent.getChildren().add(returnRouteLabel);
            
            Label returnDateLabel = new Label("Дата вылета: " + returnFlight.getDepartureTime().format(dateFormatter));
            returnDateLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
            summaryContent.getChildren().add(returnDateLabel);
            
            Label returnFlightLabel = new Label("Рейс: " + returnFlight.getAirlineName() + " " + returnFlight.getFlightNumber());
            returnFlightLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
            summaryContent.getChildren().add(returnFlightLabel);
            
            Label returnTimeLabel = new Label("Время: " + returnFlight.getDepartureTime().format(timeFormatter) + " - " + returnFlight.getArrivalTime().format(timeFormatter));
            returnTimeLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
            summaryContent.getChildren().add(returnTimeLabel);
        }
        
        Label separator2 = new Label("─────────────────");
        separator2.setStyle("-fx-text-fill: white; -fx-font-size: 12px; -fx-padding: 5 0;");
        summaryContent.getChildren().add(separator2);
        
        Label passengersLabel = new Label("Пассажиры: " + searchParams.getAdults() + " взросл., " + searchParams.getChildren() + " дет., " + searchParams.getInfants() + " млад.");
        passengersLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
        summaryContent.getChildren().add(passengersLabel);
        
        Label classLabel = new Label("Класс: " + searchParams.getServiceClass());
        classLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
        summaryContent.getChildren().add(classLabel);
        
        if (searchParams.isExtraBaggage()) {
            Label baggageLabel = new Label("Доп. багаж: Да");
            baggageLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
            summaryContent.getChildren().add(baggageLabel);
        }
        
        BigDecimal totalPrice = calculateTotalPrice();
        totalPriceLabel.setText("Итого: " + totalPrice + " ₽");
    }
    
    private BigDecimal calculateTotalPrice() {
        if (roundTrip == null || roundTrip.getOutboundFlight() == null) {
            return BigDecimal.ZERO;
        }
        
        BigDecimal totalPrice = BigDecimal.ZERO;
        int totalPassengers = searchParams.getTotalPassengers();
        
        double classMultiplier = 1.0;
        switch (searchParams.getServiceClass()) {
            case "Премиум": classMultiplier = 1.5; break;
            case "Бизнес": classMultiplier = 2.0; break;
        }
        
        // Цена за рейс туда
        BigDecimal outboundPrice = roundTrip.getOutboundFlight().getBasePrice()
                .multiply(new BigDecimal(classMultiplier))
                .multiply(new BigDecimal(totalPassengers));
        totalPrice = totalPrice.add(outboundPrice);
        
        // Цена за рейс обратно
        if (roundTrip.getReturnFlight() != null) {
            BigDecimal returnPrice = roundTrip.getReturnFlight().getBasePrice()
                    .multiply(new BigDecimal(classMultiplier))
                    .multiply(new BigDecimal(totalPassengers));
            totalPrice = totalPrice.add(returnPrice);
        }
        
        // Дополнительный багаж (один раз для всей поездки)
        BigDecimal baggageFee = searchParams.isExtraBaggage() ? new BigDecimal("2000") : BigDecimal.ZERO;
        totalPrice = totalPrice.add(baggageFee);
        
        return totalPrice;
    }
    
    @FXML
    private void handlePayment() {
        // Валидация данных пассажиров
        for (PassengerForm form : passengerFormList) {
            if (!form.validate()) {
                showError("Заполните корректно все данные пассажиров");
                return;
            }
        }
        
        // Валидация карты
        if (!validateCard()) {
            return;
        }
        
        // Создание бронирований
        new Thread(() -> {
            try {
                if (roundTrip == null || roundTrip.getOutboundFlight() == null) {
                    Platform.runLater(() -> {
                        openPaymentResult(null, false);
                    });
                    return;
                }
                
                // Создаем бронирование для рейса туда
                Booking outboundBooking = new Booking();
                outboundBooking.setUserId(SessionManager.getInstance().getCurrentUser() != null ? 
                    SessionManager.getInstance().getCurrentUser().getId() : null);
                outboundBooking.setFlightId(roundTrip.getOutboundFlight().getId());
                outboundBooking.setAdults(searchParams.getAdults());
                outboundBooking.setChildren(searchParams.getChildren());
                outboundBooking.setInfants(searchParams.getInfants());
                outboundBooking.setServiceClass(searchParams.getServiceClass());
                outboundBooking.setExtraBaggage(searchParams.isExtraBaggage());
                
                BigDecimal outboundPrice = calculateFlightPrice(roundTrip.getOutboundFlight());
                outboundBooking.setTotalPrice(outboundPrice);
                
                Booking createdOutboundBooking = supabaseClient.createBooking(outboundBooking);
                
                // Создаем бронирование для рейса обратно
                Booking returnBooking = null;
                if (roundTrip.getReturnFlight() != null) {
                    returnBooking = new Booking();
                    returnBooking.setUserId(SessionManager.getInstance().getCurrentUser() != null ? 
                        SessionManager.getInstance().getCurrentUser().getId() : null);
                    returnBooking.setFlightId(roundTrip.getReturnFlight().getId());
                    returnBooking.setAdults(searchParams.getAdults());
                    returnBooking.setChildren(searchParams.getChildren());
                    returnBooking.setInfants(searchParams.getInfants());
                    returnBooking.setServiceClass(searchParams.getServiceClass());
                    returnBooking.setExtraBaggage(false); // Багаж уже учтен в первом бронировании
                    
                    BigDecimal returnPrice = calculateFlightPrice(roundTrip.getReturnFlight());
                    returnBooking.setTotalPrice(returnPrice);
                    
                    returnBooking = supabaseClient.createBooking(returnBooking);
                }
                
                // Создание пассажиров для рейса туда
                for (PassengerForm form : passengerFormList) {
                    Passenger passenger = form.getPassenger();
                    passenger.setBookingId(createdOutboundBooking.getId());
                    supabaseClient.createPassenger(passenger);
                }
                
                // Создание пассажиров для рейса обратно (если есть)
                if (returnBooking != null) {
                    for (PassengerForm form : passengerFormList) {
                        Passenger passenger = form.getPassenger();
                        passenger.setBookingId(returnBooking.getId());
                        supabaseClient.createPassenger(passenger);
                    }
                }
                
                Platform.runLater(() -> {
                    openPaymentResult(createdOutboundBooking, true);
                });
            } catch (IOException e) {
                e.printStackTrace();
                Platform.runLater(() -> {
                    openPaymentResult(null, false);
                });
            }
        }).start();
    }
    
    private BigDecimal calculateFlightPrice(Flight flight) {
        BigDecimal basePrice = flight.getBasePrice();
        int totalPassengers = searchParams.getTotalPassengers();
        
        double classMultiplier = 1.0;
        switch (searchParams.getServiceClass()) {
            case "Премиум": classMultiplier = 1.5; break;
            case "Бизнес": classMultiplier = 2.0; break;
        }
        
        return basePrice.multiply(new BigDecimal(classMultiplier))
                .multiply(new BigDecimal(totalPassengers));
    }
    
    private boolean validateCard() {
        String cardNum = cardNumber.getText().replaceAll("\\s", "");
        String expiry = cardExpiry.getText().trim();
        String cvv = cardCVV.getText().trim();
        
        if (cardNum.length() != 16 || !cardNum.matches("\\d{16}")) {
            showError("Номер карты должен содержать 16 цифр");
            return false;
        }
        
        if (!EXPIRY_PATTERN.matcher(expiry).matches()) {
            showError("Неверный формат срока действия (ММ/ГГ)");
            return false;
        }
        
        // Проверка актуальности даты
        String[] parts = expiry.split("/");
        int month = Integer.parseInt(parts[0]);
        int year = 2000 + Integer.parseInt(parts[1]);
        LocalDate expiryDate = LocalDate.of(year, month, 1).withDayOfMonth(
            LocalDate.of(year, month, 1).lengthOfMonth()
        );
        if (expiryDate.isBefore(LocalDate.now())) {
            showError("Срок действия карты истек");
            return false;
        }
        
        if (!CVV_PATTERN.matcher(cvv).matches()) {
            showError("CVV должен содержать 3 цифры");
            return false;
        }
        
        return true;
    }
    
    private void openPaymentResult(Booking booking, boolean success) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo8/payment-result-view.fxml"));
            Stage stage = (Stage) summaryBox.getScene().getWindow();
            Scene scene = new Scene(loader.load());
            try {
                scene.getStylesheets().add(getClass().getResource("/com/example/demo8/styles.css").toExternalForm());
            } catch (Exception e) {}
            stage.setScene(scene);
            stage.setTitle("Результат оплаты");
            
            PaymentResultController controller = loader.getController();
            controller.setResult(booking, success);
        } catch (IOException e) {
            showError("Ошибка открытия результата оплаты: " + e.getMessage());
        }
    }
    
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    // Внутренний класс для формы пассажира
    private class PassengerForm {
        private TextField firstNameField;
        private TextField lastNameField;
        private TextField dateOfBirthField;
        private TextField documentNumberField;
        private VBox container;
        
        public PassengerForm(int passengerNumber) {
            container = new VBox(10);
            container.setStyle("-fx-background-color: rgba(255,255,255,0.05); -fx-background-radius: 5; -fx-padding: 15;");
            
            Label title = new Label("Пассажир " + passengerNumber);
            title.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");
            container.getChildren().add(title);
            
            HBox nameBox = new HBox(10);
            VBox firstNameBox = new VBox(5);
            Label firstNameLabel = new Label("Имя *");
            firstNameLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
            firstNameField = new TextField();
            firstNameField.setStyle("-fx-background-color: white; -fx-font-size: 14px; -fx-padding: 8;");
            
            // Валидация имени - только буквы (кириллица и латиница)
            UnaryOperator<TextFormatter.Change> nameFilter = change -> {
                String newText = change.getControlNewText();
                if (newText.isEmpty() || newText.matches("^[А-Яа-яA-Za-z\\s]*$")) {
                    return change;
                }
                return null;
            };
            firstNameField.setTextFormatter(new TextFormatter<>(nameFilter));
            firstNameField.textProperty().addListener((obs, oldVal, newVal) -> {
                validateNameField(firstNameField, newVal);
            });
            
            firstNameBox.getChildren().addAll(firstNameLabel, firstNameField);
            
            VBox lastNameBox = new VBox(5);
            Label lastNameLabel = new Label("Фамилия *");
            lastNameLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
            lastNameField = new TextField();
            lastNameField.setStyle("-fx-background-color: white; -fx-font-size: 14px; -fx-padding: 8;");
            
            // Валидация фамилии - только буквы (кириллица и латиница)
            lastNameField.setTextFormatter(new TextFormatter<>(nameFilter));
            lastNameField.textProperty().addListener((obs, oldVal, newVal) -> {
                validateNameField(lastNameField, newVal);
            });
            
            lastNameBox.getChildren().addAll(lastNameLabel, lastNameField);
            
            nameBox.getChildren().addAll(firstNameBox, lastNameBox);
            container.getChildren().add(nameBox);
            
            HBox detailsBox = new HBox(10);
            VBox dobBox = new VBox(5);
            Label dobLabel = new Label("Дата рождения (ДД.ММ.ГГГГ) *");
            dobLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
            dateOfBirthField = new TextField();
            dateOfBirthField.setPromptText("ДД.ММ.ГГГГ");
            dateOfBirthField.setStyle("-fx-background-color: white; -fx-font-size: 14px; -fx-padding: 8;");
            
            // Валидация даты рождения - только цифры и точки, формат ДД.ММ.ГГГГ
            UnaryOperator<TextFormatter.Change> dateFilter = change -> {
                String newText = change.getControlNewText();
                // Разрешаем только цифры и точки, максимум 10 символов (ДД.ММ.ГГГГ)
                if (newText.matches("^\\d{0,2}(\\.\\d{0,2}(\\.\\d{0,4})?)?$")) {
                    return change;
                }
                return null;
            };
            dateOfBirthField.setTextFormatter(new TextFormatter<>(dateFilter));
            dateOfBirthField.textProperty().addListener((obs, oldVal, newVal) -> {
                validateDateField(dateOfBirthField, newVal);
            });
            dobBox.getChildren().addAll(dobLabel, dateOfBirthField);
            
            VBox docBox = new VBox(5);
            Label docLabel = new Label("Номер документа (10 цифр) *");
            docLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
            documentNumberField = new TextField();
            documentNumberField.setStyle("-fx-background-color: white; -fx-font-size: 14px; -fx-padding: 8;");
            
            // Валидация номера документа - только цифры, максимум 10
            UnaryOperator<TextFormatter.Change> docFilter = change -> {
                String newText = change.getControlNewText();
                if (newText.matches("\\d{0,10}")) {
                    return change;
                }
                return null;
            };
            documentNumberField.setTextFormatter(new TextFormatter<>(docFilter));
            documentNumberField.textProperty().addListener((obs, oldVal, newVal) -> {
                validateDocumentField(documentNumberField, newVal);
            });
            
            docBox.getChildren().addAll(docLabel, documentNumberField);
            
            detailsBox.getChildren().addAll(dobBox, docBox);
            container.getChildren().add(detailsBox);
        }
        
        private void validateNameField(TextField field, String value) {
            if (value.isEmpty()) {
                field.setStyle("-fx-background-color: white; -fx-font-size: 14px; -fx-padding: 8; -fx-border-color: transparent;");
            } else if (NAME_PATTERN.matcher(value).matches()) {
                field.setStyle("-fx-background-color: white; -fx-font-size: 14px; -fx-padding: 8; -fx-border-color: #4CAF50; -fx-border-width: 2; -fx-border-radius: 3;");
            } else {
                field.setStyle("-fx-background-color: #ffebee; -fx-font-size: 14px; -fx-padding: 8; -fx-border-color: #f44336; -fx-border-width: 2; -fx-border-radius: 3;");
            }
        }
        
        private void validateDateField(TextField field, String value) {
            if (value.isEmpty()) {
                field.setStyle("-fx-background-color: white; -fx-font-size: 14px; -fx-padding: 8; -fx-border-color: transparent;");
            } else {
                // Проверяем формат ДД.ММ.ГГГГ
                if (value.matches("^\\d{2}\\.\\d{2}\\.\\d{4}$")) {
                    try {
                        String[] parts = value.split("\\.");
                        int day = Integer.parseInt(parts[0]);
                        int month = Integer.parseInt(parts[1]);
                        int year = Integer.parseInt(parts[2]);
                        
                        LocalDate date = LocalDate.of(year, month, day);
                        LocalDate today = LocalDate.now();
                        
                        if (date.isAfter(today) || date.isBefore(today.minusYears(120))) {
                            field.setStyle("-fx-background-color: #ffebee; -fx-font-size: 14px; -fx-padding: 8; -fx-border-color: #f44336; -fx-border-width: 2; -fx-border-radius: 3;");
                        } else {
                            field.setStyle("-fx-background-color: white; -fx-font-size: 14px; -fx-padding: 8; -fx-border-color: #4CAF50; -fx-border-width: 2; -fx-border-radius: 3;");
                        }
                    } catch (Exception e) {
                        field.setStyle("-fx-background-color: #ffebee; -fx-font-size: 14px; -fx-padding: 8; -fx-border-color: #f44336; -fx-border-width: 2; -fx-border-radius: 3;");
                    }
                } else {
                    field.setStyle("-fx-background-color: #ffebee; -fx-font-size: 14px; -fx-padding: 8; -fx-border-color: #f44336; -fx-border-width: 2; -fx-border-radius: 3;");
                }
            }
        }
        
        private void validateDocumentField(TextField field, String value) {
            if (value.isEmpty()) {
                field.setStyle("-fx-background-color: white; -fx-font-size: 14px; -fx-padding: 8; -fx-border-color: transparent;");
            } else if (DOCUMENT_PATTERN.matcher(value).matches()) {
                field.setStyle("-fx-background-color: white; -fx-font-size: 14px; -fx-padding: 8; -fx-border-color: #4CAF50; -fx-border-width: 2; -fx-border-radius: 3;");
            } else {
                field.setStyle("-fx-background-color: #ffebee; -fx-font-size: 14px; -fx-padding: 8; -fx-border-color: #f44336; -fx-border-width: 2; -fx-border-radius: 3;");
            }
        }
        
        public boolean validate() {
            String firstName = firstNameField.getText().trim();
            String lastName = lastNameField.getText().trim();
            String dobText = dateOfBirthField.getText().trim();
            String docNumber = documentNumberField.getText().trim();
            
            if (firstName.isEmpty() || !NAME_PATTERN.matcher(firstName).matches()) {
                return false;
            }
            if (lastName.isEmpty() || !NAME_PATTERN.matcher(lastName).matches()) {
                return false;
            }
            // Проверяем формат даты ДД.ММ.ГГГГ
            if (dobText.isEmpty() || !dobText.matches("^\\d{2}\\.\\d{2}\\.\\d{4}$")) {
                return false;
            }
            try {
                String[] parts = dobText.split("\\.");
                int day = Integer.parseInt(parts[0]);
                int month = Integer.parseInt(parts[1]);
                int year = Integer.parseInt(parts[2]);
                LocalDate dob = LocalDate.of(year, month, day);
                LocalDate today = LocalDate.now();
                if (dob.isAfter(today) || dob.isBefore(today.minusYears(120))) {
                    return false;
                }
            } catch (Exception e) {
                return false;
            }
            if (!DOCUMENT_PATTERN.matcher(docNumber).matches()) {
                return false;
            }
            
            return true;
        }
        
        public Passenger getPassenger() {
            Passenger passenger = new Passenger();
            passenger.setFirstName(firstNameField.getText().trim());
            passenger.setLastName(lastNameField.getText().trim());
            
            // Парсим дату из текстового поля
            String dobText = dateOfBirthField.getText().trim();
            try {
                String[] parts = dobText.split("\\.");
                int day = Integer.parseInt(parts[0]);
                int month = Integer.parseInt(parts[1]);
                int year = Integer.parseInt(parts[2]);
                passenger.setDateOfBirth(LocalDate.of(year, month, day));
            } catch (Exception e) {
                // Если не удалось распарсить, используем текущую дату (не должно произойти после валидации)
                passenger.setDateOfBirth(LocalDate.now());
            }
            
            passenger.setDocumentNumber(documentNumberField.getText().trim());
            return passenger;
        }
        
        public VBox getContainer() {
            return container;
        }
    }
}

