package com.example.demo8.controllers;

import com.example.demo8.models.Flight;
import com.example.demo8.models.RoundTrip;
import com.example.demo8.models.User;
import com.example.demo8.services.SupabaseClient;
import com.example.demo8.utils.SessionManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.function.UnaryOperator;
import java.util.regex.Pattern;

public class AuthController {
    @FXML private Label titleLabel;
    @FXML private VBox loginForm;
    @FXML private VBox registerForm;
    @FXML private Label switchToRegisterLabel;
    @FXML private Label switchToLoginLabel;
    @FXML private TextField loginEmailOrPhone;
    @FXML private PasswordField loginPassword;
    @FXML private TextField registerEmail;
    @FXML private TextField registerPhone;
    @FXML private PasswordField registerPassword;
    
    private boolean isLoginMode = true;
    private MainController mainController;
    private ResultsController resultsController;
    private Flight selectedFlight;
    private RoundTrip selectedRoundTrip;
    private SupabaseClient supabaseClient;
    
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^\\d{11}$");
    private static final Pattern EMAIL_OR_PHONE_PATTERN = Pattern.compile("^([A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}|\\d{11})$");
    
    public void initialize() {
        supabaseClient = new SupabaseClient();
        updateFormVisibility();
        setupValidation();
    }
    
    private void setupValidation() {
        // Валидация email в регистрации - только допустимые символы для email
        UnaryOperator<TextFormatter.Change> emailFilter = change -> {
            String newText = change.getControlNewText();
            if (newText.isEmpty() || newText.matches("^[A-Za-z0-9+_.-@]*$")) {
                return change;
            }
            return null;
        };
        registerEmail.setTextFormatter(new TextFormatter<>(emailFilter));
        registerEmail.textProperty().addListener((obs, oldVal, newVal) -> {
            validateEmailField(registerEmail, newVal);
        });
        
        // Валидация телефона - только цифры, максимум 11
        UnaryOperator<TextFormatter.Change> phoneFilter = change -> {
            String newText = change.getControlNewText();
            if (newText.matches("\\d{0,11}")) {
                return change;
            }
            return null;
        };
        registerPhone.setTextFormatter(new TextFormatter<>(phoneFilter));
        registerPhone.textProperty().addListener((obs, oldVal, newVal) -> {
            validatePhoneField(registerPhone, newVal);
        });
        
        // Валидация поля входа (email или телефон) - ограничение ввода
        UnaryOperator<TextFormatter.Change> loginFilter = change -> {
            String newText = change.getControlNewText();
            // Разрешаем буквы, цифры, @, ., +, -, _ для email или только цифры для телефона
            if (newText.isEmpty() || newText.matches("^[A-Za-z0-9+_.-@]*$")) {
                return change;
            }
            return null;
        };
        loginEmailOrPhone.setTextFormatter(new TextFormatter<>(loginFilter));
        loginEmailOrPhone.textProperty().addListener((obs, oldVal, newVal) -> {
            validateLoginField(loginEmailOrPhone, newVal);
        });
        
        // Валидация пароля в регистрации
        registerPassword.textProperty().addListener((obs, oldVal, newVal) -> {
            validatePasswordField(registerPassword, newVal);
        });
    }
    
    private void validatePasswordField(PasswordField field, String value) {
        if (value.isEmpty()) {
            field.setStyle("-fx-background-color: white; -fx-font-size: 12px; -fx-padding: 7; -fx-border-color: transparent;");
        } else if (value.length() >= 6) {
            field.setStyle("-fx-background-color: white; -fx-font-size: 12px; -fx-padding: 7; -fx-border-color: #4CAF50; -fx-border-width: 2; -fx-border-radius: 3;");
        } else {
            field.setStyle("-fx-background-color: #ffebee; -fx-font-size: 12px; -fx-padding: 7; -fx-border-color: #f44336; -fx-border-width: 2; -fx-border-radius: 3;");
        }
    }
    
    private void validateEmailField(TextField field, String value) {
        if (value.isEmpty()) {
            field.setStyle("-fx-background-color: white; -fx-font-size: 12px; -fx-padding: 7; -fx-border-color: transparent;");
        } else if (EMAIL_PATTERN.matcher(value).matches()) {
            field.setStyle("-fx-background-color: white; -fx-font-size: 12px; -fx-padding: 7; -fx-border-color: #4CAF50; -fx-border-width: 2; -fx-border-radius: 3;");
        } else {
            field.setStyle("-fx-background-color: #ffebee; -fx-font-size: 12px; -fx-padding: 7; -fx-border-color: #f44336; -fx-border-width: 2; -fx-border-radius: 3;");
        }
    }
    
    private void validatePhoneField(TextField field, String value) {
        if (value.isEmpty()) {
            field.setStyle("-fx-background-color: white; -fx-font-size: 12px; -fx-padding: 7; -fx-border-color: transparent;");
        } else if (PHONE_PATTERN.matcher(value).matches()) {
            field.setStyle("-fx-background-color: white; -fx-font-size: 12px; -fx-padding: 7; -fx-border-color: #4CAF50; -fx-border-width: 2; -fx-border-radius: 3;");
        } else {
            field.setStyle("-fx-background-color: #ffebee; -fx-font-size: 12px; -fx-padding: 7; -fx-border-color: #f44336; -fx-border-width: 2; -fx-border-radius: 3;");
        }
    }
    
    private void validateLoginField(TextField field, String value) {
        if (value.isEmpty()) {
            field.setStyle("-fx-background-color: white; -fx-font-size: 12px; -fx-padding: 7; -fx-border-color: transparent;");
        } else if (EMAIL_OR_PHONE_PATTERN.matcher(value).matches()) {
            field.setStyle("-fx-background-color: white; -fx-font-size: 12px; -fx-padding: 7; -fx-border-color: #4CAF50; -fx-border-width: 2; -fx-border-radius: 3;");
        } else {
            field.setStyle("-fx-background-color: #ffebee; -fx-font-size: 12px; -fx-padding: 7; -fx-border-color: #f44336; -fx-border-width: 2; -fx-border-radius: 3;");
        }
    }
    
    public void setLoginMode(boolean isLogin) {
        this.isLoginMode = isLogin;
        updateFormVisibility();
    }
    
    public void setMainController(MainController controller) {
        this.mainController = controller;
    }
    
    public void setResultsController(ResultsController controller) {
        this.resultsController = controller;
    }
    
    public void setSelectedFlight(Flight flight) {
        this.selectedFlight = flight;
    }
    
    public void setSelectedRoundTrip(RoundTrip roundTrip) {
        this.selectedRoundTrip = roundTrip;
    }
    
    private void updateFormVisibility() {
        loginForm.setVisible(isLoginMode);
        registerForm.setVisible(!isLoginMode);
        titleLabel.setText(isLoginMode ? "Вход" : "Регистрация");
    }
    
    @FXML
    private void switchToRegister(MouseEvent event) {
        isLoginMode = false;
        updateFormVisibility();
    }
    
    @FXML
    private void switchToLogin(MouseEvent event) {
        isLoginMode = true;
        updateFormVisibility();
    }
    
    @FXML
    private void handleLogin() {
        String emailOrPhone = loginEmailOrPhone.getText().trim();
        String password = loginPassword.getText();
        
        if (emailOrPhone.isEmpty() || password.isEmpty()) {
            showError("Заполните все поля");
            return;
        }
        
        // Валидация формата email или телефона
        if (!EMAIL_OR_PHONE_PATTERN.matcher(emailOrPhone).matches()) {
            showError("Введите корректный email (например: user@example.com) или номер телефона (11 цифр)");
            loginEmailOrPhone.setStyle("-fx-background-color: #ffebee; -fx-font-size: 12px; -fx-padding: 7; -fx-border-color: #f44336; -fx-border-width: 2; -fx-border-radius: 3;");
            return;
        }
        
        new Thread(() -> {
            try {
                User user = supabaseClient.loginUser(emailOrPhone, password);
                Platform.runLater(() -> {
                    if (user != null) {
                        SessionManager.getInstance().setCurrentUser(user);
                        if (mainController != null) {
                            mainController.updateUI();
                        }
                        Stage stage = (Stage) loginForm.getScene().getWindow();
                        stage.close();
                        
                        if (resultsController != null) {
                            if (selectedRoundTrip != null) {
                                resultsController.openBookingWindow(selectedRoundTrip);
                            } else if (selectedFlight != null) {
                                // Для обратной совместимости
                                RoundTrip rt = new RoundTrip(selectedFlight, null);
                                resultsController.openBookingWindow(rt);
                            }
                        }
                    } else {
                        showError("Неверный email/телефон или пароль");
                    }
                });
            } catch (IOException e) {
                Platform.runLater(() -> showError("Ошибка входа: " + e.getMessage()));
            }
        }).start();
    }
    
    @FXML
    private void handleRegister() {
        String email = registerEmail.getText().trim();
        String phone = registerPhone.getText().trim();
        String password = registerPassword.getText();
        
        if (email.isEmpty() || phone.isEmpty() || password.isEmpty()) {
            showError("Заполните все поля");
            return;
        }
        
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            showError("Неверный формат email");
            return;
        }
        
        if (!PHONE_PATTERN.matcher(phone).matches()) {
            showError("Номер телефона должен содержать 11 цифр");
            return;
        }
        
        if (password.length() < 6) {
            showError("Пароль должен содержать минимум 6 символов");
            return;
        }
        
        new Thread(() -> {
            try {
                User user = supabaseClient.registerUser(email, phone, password);
                Platform.runLater(() -> {
                    if (user != null) {
                        SessionManager.getInstance().setCurrentUser(user);
                        if (mainController != null) {
                            mainController.updateUI();
                        }
                        Stage stage = (Stage) registerForm.getScene().getWindow();
                        stage.close();
                        
                        if (resultsController != null) {
                            if (selectedRoundTrip != null) {
                                resultsController.openBookingWindow(selectedRoundTrip);
                            } else if (selectedFlight != null) {
                                // Для обратной совместимости
                                RoundTrip rt = new RoundTrip(selectedFlight, null);
                                resultsController.openBookingWindow(rt);
                            }
                        }
                    } else {
                        showError("Ошибка регистрации. Возможно, пользователь с таким email или телефоном уже существует");
                    }
                });
            } catch (IOException e) {
                Platform.runLater(() -> showError("Ошибка регистрации: " + e.getMessage()));
            }
        }).start();
    }
    
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}



