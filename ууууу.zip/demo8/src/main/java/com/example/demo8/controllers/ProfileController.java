package com.example.demo8.controllers;

import com.example.demo8.models.Booking;
import com.example.demo8.models.User;
import com.example.demo8.services.SupabaseClient;
import com.example.demo8.utils.SessionManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.regex.Pattern;

public class ProfileController {
    @FXML private TextField bookingSearchField;
    @FXML private VBox bookingResultBox;
    @FXML private VBox bookingsList;
    @FXML private TextField emailField;
    @FXML private TextField phoneField;
    
    private SupabaseClient supabaseClient;
    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^\\d{11}$");
    
    public void initialize() {
        supabaseClient = new SupabaseClient();
        loadUserInfo();
        loadBookings();
    }
    
    private void loadUserInfo() {
        User user = SessionManager.getInstance().getCurrentUser();
        if (user != null) {
            emailField.setText(user.getEmail());
            phoneField.setText(user.getPhone());
        }
    }
    
    private void loadBookings() {
        User user = SessionManager.getInstance().getCurrentUser();
        if (user == null) return;
        
        new Thread(() -> {
            try {
                List<Booking> bookings = supabaseClient.getUserBookings(user.getId());
                Platform.runLater(() -> {
                    bookingsList.getChildren().clear();
                    if (bookings.isEmpty()) {
                        Label noBookings = new Label("Нет бронирований");
                        noBookings.setStyle("-fx-text-fill: white; -fx-font-size: 16px;");
                        bookingsList.getChildren().add(noBookings);
                    } else {
                        for (Booking booking : bookings) {
                            bookingsList.getChildren().add(createBookingCard(booking));
                        }
                    }
                });
            } catch (IOException e) {
                Platform.runLater(() -> {
                    Label error = new Label("Ошибка загрузки бронирований: " + e.getMessage());
                    error.setStyle("-fx-text-fill: red; -fx-font-size: 14px;");
                    bookingsList.getChildren().add(error);
                });
            }
        }).start();
    }
    
    @FXML
    private void handleSearchBooking() {
        String bookingNumber = bookingSearchField.getText().trim();
        if (bookingNumber.isEmpty()) {
            showError("Введите номер бронирования");
            return;
        }
        
        new Thread(() -> {
            try {
                Booking booking = supabaseClient.findBookingByNumber(bookingNumber);
                Platform.runLater(() -> {
                    bookingResultBox.getChildren().clear();
                    if (booking != null) {
                        bookingResultBox.setVisible(true);
                        
                        Label numberLabel = new Label("Номер бронирования: " + booking.getBookingNumber());
                        numberLabel.setStyle("-fx-text-fill: white; -fx-font-size: 18px; -fx-font-weight: bold;");
                        bookingResultBox.getChildren().add(numberLabel);
                        
                        if (booking.getFlight() != null) {
                            Label routeLabel = new Label("Маршрут: " + booking.getFlight().getFromCityName() + " → " + booking.getFlight().getToCityName());
                            routeLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
                            bookingResultBox.getChildren().add(routeLabel);
                            
                            Label flightLabel = new Label("Рейс: " + booking.getFlight().getAirlineName() + " " + booking.getFlight().getFlightNumber());
                            flightLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
                            bookingResultBox.getChildren().add(flightLabel);
                            
                            Label statusLabel = new Label("Статус: " + booking.getStatus());
                            statusLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
                            bookingResultBox.getChildren().add(statusLabel);
                            
                            Label priceLabel = new Label("Сумма: " + booking.getTotalPrice() + " ₽");
                            priceLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
                            bookingResultBox.getChildren().add(priceLabel);
                        }
                    } else {
                        bookingResultBox.setVisible(true);
                        Label notFound = new Label("Бронирование не найдено");
                        notFound.setStyle("-fx-text-fill: white; -fx-font-size: 16px;");
                        bookingResultBox.getChildren().add(notFound);
                    }
                });
            } catch (IOException e) {
                Platform.runLater(() -> {
                    showError("Ошибка поиска: " + e.getMessage());
                });
            }
        }).start();
    }
    
    @FXML
    private void handleSaveProfile() {
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        
        if (email.isEmpty() || phone.isEmpty()) {
            showError("Заполните все поля");
            return;
        }
        
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            showError("Неверный формат email");
            return;
        }
        
        if (!PHONE_PATTERN.matcher(phone).matches()) {
            showError("Номер телефона должен содержать 11 цифр");
            return;
        }
        
        User user = SessionManager.getInstance().getCurrentUser();
        if (user == null) return;
        
        new Thread(() -> {
            try {
                supabaseClient.updateUser(user.getId(), email, phone);
                Platform.runLater(() -> {
                    user.setEmail(email);
                    user.setPhone(phone);
                    showSuccess("Данные успешно обновлены");
                });
            } catch (IOException e) {
                Platform.runLater(() -> {
                    showError("Ошибка обновления данных: " + e.getMessage());
                });
            }
        }).start();
    }
    
    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo8/main-view.fxml"));
            Stage stage = (Stage) bookingSearchField.getScene().getWindow();
            Scene scene = new Scene(loader.load());
            try {
                scene.getStylesheets().add(getClass().getResource("/com/example/demo8/styles.css").toExternalForm());
            } catch (Exception e) {}
            stage.setScene(scene);
            stage.setTitle("Поиск авиабилетов");
        } catch (IOException e) {
            showError("Ошибка возврата: " + e.getMessage());
        }
    }
    
    private VBox createBookingCard(Booking booking) {
        VBox card = new VBox(10);
        card.setStyle("-fx-background-color: rgba(255,255,255,0.1); -fx-background-radius: 10; -fx-padding: 20; -fx-pref-width: 1100;");
        
        Label numberLabel = new Label("Бронирование: " + booking.getBookingNumber());
        numberLabel.setStyle("-fx-text-fill: white; -fx-font-size: 18px; -fx-font-weight: bold;");
        card.getChildren().add(numberLabel);
        
        if (booking.getFlight() != null) {
            Label routeLabel = new Label("Маршрут: " + booking.getFlight().getFromCityName() + " → " + booking.getFlight().getToCityName());
            routeLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
            card.getChildren().add(routeLabel);
            
            Label flightLabel = new Label("Рейс: " + booking.getFlight().getAirlineName() + " " + booking.getFlight().getFlightNumber());
            flightLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
            card.getChildren().add(flightLabel);
        }
        
        Label statusLabel = new Label("Статус: " + booking.getStatus());
        statusLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
        card.getChildren().add(statusLabel);
        
        Label priceLabel = new Label("Сумма: " + booking.getTotalPrice() + " ₽");
        priceLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
        card.getChildren().add(priceLabel);
        
        return card;
    }
    
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    private void showSuccess(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Успех");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

