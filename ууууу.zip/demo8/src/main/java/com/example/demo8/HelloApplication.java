package com.example.demo8;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("/com/example/demo8/main-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1200, 800);
        
        // Применяем глобальные стили
        try {
            scene.getStylesheets().add(getClass().getResource("/com/example/demo8/styles.css").toExternalForm());
        } catch (Exception e) {
            System.err.println("Не удалось загрузить CSS файл: " + e.getMessage());
        }
        
        stage.setTitle("Авиакасса - Поиск билетов");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}