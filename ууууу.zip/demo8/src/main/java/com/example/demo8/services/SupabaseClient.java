package com.example.demo8.services;

import com.example.demo8.models.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import okhttp3.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class SupabaseClient {
    private static final String SUPABASE_URL = "https://qeeytfzjsbuuxeitfmaj.supabase.co";
    private static final String SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFlZXl0Znpqc2J1dXhlaXRmbWFqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM1NzMxODUsImV4cCI6MjA3OTE0OTE4NX0.c6oJHifKqFTuz8n9HiBCriE1bi4dHucd81-M6wQ2_C0";
    
    private final OkHttpClient client;
    private final Gson gson;
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
    
    public SupabaseClient() {
        this.client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();
        this.gson = new GsonBuilder()
                .setPrettyPrinting()
                .create();
    }
    
    private Request.Builder getRequestBuilder(String endpoint) {
        return new Request.Builder()
                .url(SUPABASE_URL + "/rest/v1/" + endpoint)
                .addHeader("apikey", SUPABASE_KEY)
                .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                .addHeader("Content-Type", "application/json")
                .addHeader("Prefer", "return=representation");
    }
    
    // Получить все города
    public List<City> getCities() throws IOException {
        Request request = getRequestBuilder("cities?select=*")
                .get()
                .build();
        
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Ошибка получения городов: " + response.code());
            }
            
            String json = response.body().string();
            JsonArray array = gson.fromJson(json, JsonArray.class);
            List<City> cities = new ArrayList<>();
            
            for (int i = 0; i < array.size(); i++) {
                JsonObject obj = array.get(i).getAsJsonObject();
                City city = new City();
                city.setId(UUID.fromString(obj.get("id").getAsString()));
                city.setName(obj.get("name").getAsString());
                city.setCode(obj.get("code").getAsString());
                cities.add(city);
            }
            
            return cities;
        }
    }
    
    // Поиск рейсов туда
    public List<Flight> searchFlights(UUID fromCityId, UUID toCityId, LocalDate departureDate) throws IOException {
        String dateStr = departureDate.format(dateFormatter);
        // Получаем названия городов заранее
        City fromCity = getCityById(fromCityId);
        City toCity = getCityById(toCityId);
        
        // Формируем даты для запроса (Supabase использует ISO 8601 формат)
        // Ищем рейсы на выбранную дату и ближайшие 7 дней (чтобы найти больше вариантов)
        String startDateTime = dateStr + "T00:00:00";
        LocalDate endDate = departureDate.plusDays(7);
        String endDateTime = endDate.format(dateFormatter) + "T23:59:59";
        
        // Запрос к таблице flights - ищем рейсы в диапазоне дат
        String query = String.format(
            "flights?from_city_id=eq.%s&to_city_id=eq.%s&departure_time=gte.%s&departure_time=lte.%s&select=id,flight_number,departure_time,arrival_time,base_price,available_seats,airline_id,airlines(name)&order=departure_time.asc&limit=50",
            fromCityId, toCityId, startDateTime, endDateTime
        );
        
        System.out.println("Поиск рейсов:");
        System.out.println("  От: " + (fromCity != null ? fromCity.getName() : fromCityId));
        System.out.println("  До: " + (toCity != null ? toCity.getName() : toCityId));
        System.out.println("  Дата поиска: " + dateStr + " (и ближайшие 7 дней)");
        System.out.println("  Запрос: " + SUPABASE_URL + "/rest/v1/" + query);
        
        Request request = getRequestBuilder(query)
                .get()
                .build();
        
        try (Response response = client.newCall(request).execute()) {
            String responseBody = response.body() != null ? response.body().string() : "";
            
            if (!response.isSuccessful()) {
                System.err.println("Ошибка ответа: " + response.code() + " " + responseBody);
                throw new IOException("Ошибка поиска рейсов: " + response.code() + " " + responseBody);
            }
            
            System.out.println("Ответ получен: " + responseBody.substring(0, Math.min(200, responseBody.length())));
            
            JsonArray array = gson.fromJson(responseBody, JsonArray.class);
            List<Flight> flights = new ArrayList<>();
            
            for (int i = 0; i < array.size(); i++) {
                try {
                    JsonObject obj = array.get(i).getAsJsonObject();
                    Flight flight = new Flight();
                    flight.setId(UUID.fromString(obj.get("id").getAsString()));
                    flight.setFlightNumber(obj.get("flight_number").getAsString());
                    
                    // Получаем данные авиакомпании
                    if (obj.has("airlines") && obj.get("airlines").isJsonObject()) {
                        JsonObject airline = obj.getAsJsonObject("airlines");
                        flight.setAirlineName(airline.get("name").getAsString());
                    } else {
                        flight.setAirlineName("Неизвестная авиакомпания");
                    }
                    
                    // Устанавливаем названия городов
                    if (fromCity != null) flight.setFromCityName(fromCity.getName());
                    else flight.setFromCityName("Неизвестный город");
                    
                    if (toCity != null) flight.setToCityName(toCity.getName());
                    else flight.setToCityName("Неизвестный город");
                    
                    String depTime = obj.get("departure_time").getAsString();
                    String arrTime = obj.get("arrival_time").getAsString();
                    flight.setDepartureTime(LocalDateTime.parse(depTime.substring(0, 19)));
                    flight.setArrivalTime(LocalDateTime.parse(arrTime.substring(0, 19)));
                    
                    flight.setBasePrice(new BigDecimal(obj.get("base_price").getAsString()));
                    flight.setAvailableSeats(obj.get("available_seats").getAsInt());
                    
                    flights.add(flight);
                } catch (Exception e) {
                    System.err.println("Ошибка парсинга рейса: " + e.getMessage());
                    e.printStackTrace();
                }
            }
            
            return flights;
        }
    }
    
    // Поиск рейсов обратно
    public List<Flight> searchReturnFlights(UUID fromCityId, UUID toCityId, LocalDate returnDate) throws IOException {
        if (returnDate == null) {
            return new ArrayList<>();
        }
        
        String dateStr = returnDate.format(dateFormatter);
        // Для обратного рейса: из города назначения (toCityId) в город отправления (fromCityId)
        City returnFromCity = getCityById(toCityId);  // Город, куда летели туда
        City returnToCity = getCityById(fromCityId);   // Город, откуда летели туда
        
        // Ищем обратные рейсы на выбранную дату и ближайшие 7 дней (чтобы найти больше вариантов)
        String startDateTime = dateStr + "T00:00:00";
        LocalDate endDate = returnDate.plusDays(7);
        String endDateTime = endDate.format(dateFormatter) + "T23:59:59";
        
        // Ищем обратные рейсы (меняем местами from и to)
        String query = String.format(
            "flights?from_city_id=eq.%s&to_city_id=eq.%s&departure_time=gte.%s&departure_time=lte.%s&select=id,flight_number,departure_time,arrival_time,base_price,available_seats,airline_id,airlines(name)&order=departure_time.asc&limit=50",
            toCityId, fromCityId, startDateTime, endDateTime
        );
        
        System.out.println("Поиск обратных рейсов:");
        System.out.println("  От: " + (returnFromCity != null ? returnFromCity.getName() : toCityId));
        System.out.println("  До: " + (returnToCity != null ? returnToCity.getName() : fromCityId));
        System.out.println("  Дата: " + dateStr + " (и ближайшие 7 дней)");
        System.out.println("  Запрос: " + SUPABASE_URL + "/rest/v1/" + query);
        
        Request request = getRequestBuilder(query)
                .get()
                .build();
        
        try (Response response = client.newCall(request).execute()) {
            String responseBody = response.body() != null ? response.body().string() : "";
            
            if (!response.isSuccessful()) {
                System.err.println("Ошибка ответа: " + response.code() + " " + responseBody);
                throw new IOException("Ошибка поиска обратных рейсов: " + response.code() + " " + responseBody);
            }
            
            System.out.println("Ответ обратных рейсов: " + responseBody.substring(0, Math.min(200, responseBody.length())));
            
            JsonArray array = gson.fromJson(responseBody, JsonArray.class);
            List<Flight> flights = new ArrayList<>();
            
            for (int i = 0; i < array.size(); i++) {
                try {
                    JsonObject obj = array.get(i).getAsJsonObject();
                    Flight flight = new Flight();
                    flight.setId(UUID.fromString(obj.get("id").getAsString()));
                    flight.setFlightNumber(obj.get("flight_number").getAsString());
                    
                    if (obj.has("airlines") && obj.get("airlines").isJsonObject()) {
                        JsonObject airline = obj.getAsJsonObject("airlines");
                        flight.setAirlineName(airline.get("name").getAsString());
                    } else {
                        flight.setAirlineName("Неизвестная авиакомпания");
                    }
                    
                    // Для обратного рейса: fromCityName = город, куда летели туда, toCityName = город, откуда летели туда
                    if (returnFromCity != null) flight.setFromCityName(returnFromCity.getName());
                    else flight.setFromCityName("Неизвестный город");
                    
                    if (returnToCity != null) flight.setToCityName(returnToCity.getName());
                    else flight.setToCityName("Неизвестный город");
                    
                    String depTime = obj.get("departure_time").getAsString();
                    String arrTime = obj.get("arrival_time").getAsString();
                    flight.setDepartureTime(LocalDateTime.parse(depTime.substring(0, 19)));
                    flight.setArrivalTime(LocalDateTime.parse(arrTime.substring(0, 19)));
                    
                    flight.setBasePrice(new BigDecimal(obj.get("base_price").getAsString()));
                    flight.setAvailableSeats(obj.get("available_seats").getAsInt());
                    
                    flights.add(flight);
                } catch (Exception e) {
                    System.err.println("Ошибка парсинга обратного рейса: " + e.getMessage());
                    e.printStackTrace();
                }
            }
            
            System.out.println("Найдено обратных рейсов: " + flights.size());
            return flights;
        }
    }
    
    private City getCityById(UUID cityId) throws IOException {
        Request request = getRequestBuilder("cities?id=eq." + cityId + "&select=id,name")
                .get()
                .build();
        
        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                String json = response.body().string();
                JsonArray array = gson.fromJson(json, JsonArray.class);
                if (array.size() > 0) {
                    JsonObject obj = array.get(0).getAsJsonObject();
                    City city = new City();
                    city.setId(UUID.fromString(obj.get("id").getAsString()));
                    city.setName(obj.get("name").getAsString());
                    return city;
                }
            }
        } catch (Exception e) {
            // Игнорируем ошибки при получении города
        }
        return null;
    }
    
    // Регистрация пользователя
    public User registerUser(String email, String phone, String password) throws IOException {
        // Простое хеширование пароля (в реальном приложении используйте bcrypt)
        String passwordHash = String.valueOf(password.hashCode());
        
        JsonObject userJson = new JsonObject();
        userJson.addProperty("email", email);
        userJson.addProperty("phone", phone);
        userJson.addProperty("password_hash", passwordHash);
        
        RequestBody body = RequestBody.create(
            userJson.toString(),
            MediaType.parse("application/json")
        );
        
        // Используем специальный заголовок для обхода RLS (если настроено)
        Request request = getRequestBuilder("users")
                .post(body)
                .addHeader("Prefer", "return=representation")
                .build();
        
        try (Response response = client.newCall(request).execute()) {
            String responseBody = response.body() != null ? response.body().string() : "";
            
            if (!response.isSuccessful()) {
                System.err.println("Ошибка регистрации:");
                System.err.println("  Код: " + response.code());
                System.err.println("  Тело ответа: " + responseBody);
                
                // Парсим детали ошибки
                try {
                    JsonObject errorJson = gson.fromJson(responseBody, JsonObject.class);
                    if (errorJson.has("message")) {
                        String errorMessage = errorJson.get("message").getAsString();
                        String errorCode = errorJson.has("code") ? errorJson.get("code").getAsString() : "";
                        
                        // Обработка ошибок дублирования
                        if (errorCode.equals("23505") || errorMessage.contains("duplicate key")) {
                            if (errorMessage.contains("phone") || errorMessage.contains("users_phone_key")) {
                                throw new IOException("Пользователь с таким номером телефона уже зарегистрирован");
                            } else if (errorMessage.contains("email") || errorMessage.contains("users_email_key")) {
                                throw new IOException("Пользователь с таким email уже зарегистрирован");
                            } else {
                                throw new IOException("Пользователь с такими данными уже существует");
                            }
                        }
                        
                        if (errorMessage.contains("duplicate") || errorMessage.contains("уже существует")) {
                            throw new IOException("Пользователь с таким email или телефоном уже существует");
                        }
                        
                        throw new IOException("Ошибка регистрации: " + errorMessage);
                    }
                } catch (IOException e) {
                    // Перебрасываем IOException дальше
                    throw e;
                } catch (Exception e) {
                    // Если не удалось распарсить JSON, используем общее сообщение
                }
                
                // Обработка HTTP кодов ошибок
                if (response.code() == 409) {
                    throw new IOException("Пользователь с таким email или телефоном уже зарегистрирован");
                }
                
                if (response.code() == 401 || response.code() == 42501) {
                    throw new IOException("Ошибка доступа к базе данных. Проверьте настройки RLS политик в Supabase.\n" +
                        "Необходимо разрешить INSERT для анонимных пользователей в таблице users.");
                }
                
                throw new IOException("Ошибка регистрации: " + response.code() + " " + responseBody);
            }
            
            String json = responseBody;
            JsonArray array = gson.fromJson(json, JsonArray.class);
            if (array.size() > 0) {
                JsonObject obj = array.get(0).getAsJsonObject();
                User user = new User();
                user.setId(UUID.fromString(obj.get("id").getAsString()));
                user.setEmail(obj.get("email").getAsString());
                user.setPhone(obj.get("phone").getAsString());
                return user;
            }
            return null;
        }
    }
    
    // Вход пользователя
    public User loginUser(String emailOrPhone, String password) throws IOException {
        String passwordHash = String.valueOf(password.hashCode());
        
        String query = String.format(
            "users?or=(email.eq.%s,phone.eq.%s)&password_hash=eq.%s&select=*",
            emailOrPhone, emailOrPhone, passwordHash
        );
        
        Request request = getRequestBuilder(query)
                .get()
                .build();
        
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Ошибка входа: " + response.code());
            }
            
            String json = response.body().string();
            JsonArray array = gson.fromJson(json, JsonArray.class);
            if (array.size() > 0) {
                JsonObject obj = array.get(0).getAsJsonObject();
                User user = new User();
                user.setId(UUID.fromString(obj.get("id").getAsString()));
                user.setEmail(obj.get("email").getAsString());
                user.setPhone(obj.get("phone").getAsString());
                return user;
            }
            return null;
        }
    }
    
    // Создать бронирование
    public Booking createBooking(Booking booking) throws IOException {
        JsonObject bookingJson = new JsonObject();
        if (booking.getUserId() != null) {
            bookingJson.addProperty("user_id", booking.getUserId().toString());
        }
        bookingJson.addProperty("flight_id", booking.getFlightId().toString());
        bookingJson.addProperty("adults", booking.getAdults());
        bookingJson.addProperty("children", booking.getChildren());
        bookingJson.addProperty("infants", booking.getInfants());
        bookingJson.addProperty("service_class", booking.getServiceClass());
        bookingJson.addProperty("extra_baggage", booking.getExtraBaggage());
        bookingJson.addProperty("total_price", booking.getTotalPrice().toString());
        bookingJson.addProperty("status", "Оплачено");
        bookingJson.addProperty("payment_status", "Оплачено");
        
        RequestBody body = RequestBody.create(
            bookingJson.toString(),
            MediaType.parse("application/json")
        );
        
        Request request = getRequestBuilder("bookings")
                .post(body)
                .build();
        
        try (Response response = client.newCall(request).execute()) {
            ResponseBody responseBodyObj = response.body();
            String responseBodyString = responseBodyObj != null ? responseBodyObj.string() : "";
            
            if (!response.isSuccessful()) {
                System.err.println("Ошибка создания бронирования:");
                System.err.println("  Код: " + response.code());
                System.err.println("  Тело ответа: " + responseBodyString);
                
                if (response.code() == 401 || response.code() == 42501) {
                    throw new IOException("Ошибка доступа к базе данных. Проверьте настройки RLS политик в Supabase.\n" +
                        "Необходимо разрешить INSERT для анонимных пользователей в таблице bookings.");
                }
                
                throw new IOException("Ошибка создания бронирования: " + response.code() + " " + responseBodyString);
            }
            
            // Используем уже прочитанную строку (не читаем body повторно!)
            String json = responseBodyString;
            if (json.isEmpty()) {
                throw new IOException("Пустой ответ от сервера при создании бронирования");
            }
            
            JsonArray array = gson.fromJson(json, JsonArray.class);
            if (array.size() > 0) {
                JsonObject obj = array.get(0).getAsJsonObject();
                Booking result = new Booking();
                result.setId(UUID.fromString(obj.get("id").getAsString()));
                result.setBookingNumber(obj.get("booking_number").getAsString());
                result.setTotalPrice(new BigDecimal(obj.get("total_price").getAsString()));
                return result;
            }
            return null;
        }
    }
    
    // Создать пассажира
    public void createPassenger(Passenger passenger) throws IOException {
        JsonObject passengerJson = new JsonObject();
        passengerJson.addProperty("booking_id", passenger.getBookingId().toString());
        passengerJson.addProperty("first_name", passenger.getFirstName());
        passengerJson.addProperty("last_name", passenger.getLastName());
        passengerJson.addProperty("date_of_birth", passenger.getDateOfBirth().format(dateFormatter));
        passengerJson.addProperty("document_number", passenger.getDocumentNumber());
        passengerJson.addProperty("document_type", "Паспорт");
        
        RequestBody body = RequestBody.create(
            passengerJson.toString(),
            MediaType.parse("application/json")
        );
        
        Request request = getRequestBuilder("passengers")
                .post(body)
                .build();
        
        try (Response response = client.newCall(request).execute()) {
            ResponseBody responseBody = response.body();
            String responseBodyString = responseBody != null ? responseBody.string() : "";
            
            if (!response.isSuccessful()) {
                System.err.println("Ошибка создания пассажира:");
                System.err.println("  Код: " + response.code());
                System.err.println("  Тело ответа: " + responseBodyString);
                
                if (response.code() == 401 || response.code() == 42501) {
                    throw new IOException("Ошибка доступа к базе данных. Проверьте настройки RLS политик в Supabase.\n" +
                        "Необходимо разрешить INSERT для анонимных пользователей в таблице passengers.");
                }
                
                throw new IOException("Ошибка создания пассажира: " + response.code() + " " + responseBodyString);
            }
        }
    }
    
    // Получить бронирования пользователя
    public List<Booking> getUserBookings(UUID userId) throws IOException {
        String query = String.format(
            "bookings?user_id=eq.%s&select=*,flights(id,flight_number,departure_time,arrival_time,from_city_id,to_city_id,airlines(name))&order=booking_date.desc",
            userId
        );
        
        Request request = getRequestBuilder(query)
                .get()
                .build();
        
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Ошибка получения бронирований: " + response.code());
            }
            
            String json = response.body().string();
            JsonArray array = gson.fromJson(json, JsonArray.class);
            List<Booking> bookings = new ArrayList<>();
            
            for (int i = 0; i < array.size(); i++) {
                JsonObject obj = array.get(i).getAsJsonObject();
                Booking booking = parseBooking(obj);
                bookings.add(booking);
            }
            
            return bookings;
        }
    }
    
    // Найти бронирование по номеру
    public Booking findBookingByNumber(String bookingNumber) throws IOException {
        String query = String.format(
            "bookings?booking_number=eq.%s&select=*,flights(id,flight_number,departure_time,arrival_time,from_city_id,to_city_id,airlines(name))",
            bookingNumber
        );
        
        Request request = getRequestBuilder(query)
                .get()
                .build();
        
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Ошибка поиска бронирования: " + response.code());
            }
            
            String json = response.body().string();
            JsonArray array = gson.fromJson(json, JsonArray.class);
            if (array.size() > 0) {
                return parseBooking(array.get(0).getAsJsonObject());
            }
            return null;
        }
    }
    
    private Booking parseBooking(JsonObject obj) throws IOException {
        Booking booking = new Booking();
        booking.setId(UUID.fromString(obj.get("id").getAsString()));
        booking.setBookingNumber(obj.get("booking_number").getAsString());
        booking.setStatus(obj.get("status").getAsString());
        booking.setTotalPrice(new BigDecimal(obj.get("total_price").getAsString()));
        booking.setAdults(obj.get("adults").getAsInt());
        booking.setChildren(obj.get("children").getAsInt());
        booking.setInfants(obj.get("infants").getAsInt());
        booking.setServiceClass(obj.get("service_class").getAsString());
        booking.setExtraBaggage(obj.get("extra_baggage").getAsBoolean());
        
        // Парсим данные рейса
        if (obj.has("flights") && obj.get("flights").isJsonObject()) {
            JsonObject flightObj = obj.getAsJsonObject("flights");
            Flight flight = new Flight();
            flight.setId(UUID.fromString(flightObj.get("id").getAsString()));
            flight.setFlightNumber(flightObj.get("flight_number").getAsString());
            
            if (flightObj.has("airlines") && flightObj.get("airlines").isJsonObject()) {
                flight.setAirlineName(flightObj.getAsJsonObject("airlines").get("name").getAsString());
            }
            
            // Получаем названия городов
            UUID fromCityId = UUID.fromString(flightObj.get("from_city_id").getAsString());
            UUID toCityId = UUID.fromString(flightObj.get("to_city_id").getAsString());
            City fromCity = getCityById(fromCityId);
            City toCity = getCityById(toCityId);
            if (fromCity != null) flight.setFromCityName(fromCity.getName());
            if (toCity != null) flight.setToCityName(toCity.getName());
            
            String depTime = flightObj.get("departure_time").getAsString();
            String arrTime = flightObj.get("arrival_time").getAsString();
            flight.setDepartureTime(LocalDateTime.parse(depTime.substring(0, 19)));
            flight.setArrivalTime(LocalDateTime.parse(arrTime.substring(0, 19)));
            booking.setFlight(flight);
        }
        
        return booking;
    }
    
    // Обновить данные пользователя
    public void updateUser(UUID userId, String email, String phone) throws IOException {
        JsonObject userJson = new JsonObject();
        userJson.addProperty("email", email);
        userJson.addProperty("phone", phone);
        
        RequestBody body = RequestBody.create(
            userJson.toString(),
            MediaType.parse("application/json")
        );
        
        Request request = getRequestBuilder("users?id=eq." + userId)
                .patch(body)
                .build();
        
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Ошибка обновления данных: " + response.code());
            }
        }
    }
}

