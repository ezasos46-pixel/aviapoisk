package com.example.demo8.controllers;

import com.example.demo8.models.Flight;
import com.example.demo8.models.RoundTrip;
import com.example.demo8.models.SearchParams;
import com.example.demo8.services.SupabaseClient;
import com.example.demo8.utils.SessionManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class ResultsController {
    @FXML private VBox flightsContainer;
    @FXML private Label noResultsLabel;
    
    private SearchParams searchParams;
    private SupabaseClient supabaseClient;
    private DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    
    public void setSearchParams(SearchParams searchParams) {
        this.searchParams = searchParams;
    }
    
    public void loadFlights() {
        if (searchParams == null || searchParams.getFromCity() == null || searchParams.getToCity() == null) {
            noResultsLabel.setText("Ошибка: не указаны параметры поиска");
            noResultsLabel.setVisible(true);
            return;
        }
        
        supabaseClient = new SupabaseClient();
        flightsContainer.getChildren().clear();
        noResultsLabel.setText("Загрузка рейсов...");
        noResultsLabel.setVisible(true);
        
        new Thread(() -> {
            try {
                System.out.println("Поиск рейсов: " + searchParams.getFromCity().getName() + " -> " + 
                    searchParams.getToCity().getName() + " на " + searchParams.getDepartureDate());
                
                // Поиск рейсов туда
                var outboundFlights = supabaseClient.searchFlights(
                    searchParams.getFromCity().getId(),
                    searchParams.getToCity().getId(),
                    searchParams.getDepartureDate()
                );
                
                // Поиск рейсов обратно (если указана дата обратного вылета)
                List<Flight> returnFlights = new ArrayList<>();
                if (searchParams.getReturnDate() != null) {
                    returnFlights = supabaseClient.searchReturnFlights(
                        searchParams.getFromCity().getId(),
                        searchParams.getToCity().getId(),
                        searchParams.getReturnDate()
                    );
                }
                
                System.out.println("Найдено рейсов туда: " + outboundFlights.size());
                System.out.println("Найдено рейсов обратно: " + returnFlights.size());
                System.out.println("Дата обратного вылета: " + (searchParams.getReturnDate() != null ? searchParams.getReturnDate() : "не указана"));
                
                // Формируем связки туда-обратно
                List<RoundTrip> roundTrips = new ArrayList<>();
                if (searchParams.getReturnDate() != null) {
                    // Если указана дата обратного вылета, создаем связки
                    if (!returnFlights.isEmpty()) {
                        // Если есть обратные рейсы, создаем все возможные комбинации
                        System.out.println("Создаем связки туда-обратно: " + outboundFlights.size() + " x " + returnFlights.size() + " = " + (outboundFlights.size() * returnFlights.size()));
                        for (Flight outbound : outboundFlights) {
                            for (Flight returnFlight : returnFlights) {
                                roundTrips.add(new RoundTrip(outbound, returnFlight));
                            }
                        }
                    } else {
                        // Если обратных рейсов нет, все равно показываем рейсы туда (обратно будет пустым)
                        System.out.println("Обратные рейсы не найдены, но показываем рейсы туда с пустым обратным рейсом");
                        for (Flight outbound : outboundFlights) {
                            roundTrips.add(new RoundTrip(outbound, null));
                        }
                    }
                } else {
                    // Если дата обратного вылета не указана, показываем только туда
                    System.out.println("Дата обратного вылета не указана, показываем только рейсы туда");
                    for (Flight outbound : outboundFlights) {
                        roundTrips.add(new RoundTrip(outbound, null));
                    }
                }
                
                System.out.println("Итого создано связок: " + roundTrips.size());
                
                final List<RoundTrip> finalRoundTrips = roundTrips;
                Platform.runLater(() -> {
                    noResultsLabel.setVisible(false);
                    if (finalRoundTrips.isEmpty()) {
                        String message = "Рейсы не найдены на выбранную дату и ближайшие 7 дней.\n";
                        if (searchParams.getReturnDate() != null) {
                            message += "Дата вылета: " + searchParams.getDepartureDate().format(dateFormatter) + "\n";
                            message += "Дата обратного вылета: " + searchParams.getReturnDate().format(dateFormatter) + "\n";
                        } else {
                            message += "Дата вылета: " + searchParams.getDepartureDate().format(dateFormatter) + "\n";
                        }
                        message += "Попробуйте изменить дату или маршрут.";
                        noResultsLabel.setText(message);
                        noResultsLabel.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-text-alignment: center;");
                        noResultsLabel.setVisible(true);
                    } else {
                        // Показываем количество найденных связок
                        Label infoLabel = new Label("Найдено вариантов: " + finalRoundTrips.size());
                        infoLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10;");
                        flightsContainer.getChildren().add(infoLabel);
                        
                        for (RoundTrip roundTrip : finalRoundTrips) {
                            flightsContainer.getChildren().add(createRoundTripCard(roundTrip));
                        }
                    }
                });
            } catch (IOException e) {
                e.printStackTrace();
                Platform.runLater(() -> {
                    noResultsLabel.setText("Ошибка загрузки рейсов: " + e.getMessage() + 
                        "\nПроверьте подключение к интернету и настройки базы данных.");
                    noResultsLabel.setVisible(true);
                });
            } catch (Exception e) {
                e.printStackTrace();
                Platform.runLater(() -> {
                    noResultsLabel.setText("Неожиданная ошибка: " + e.getMessage());
                    noResultsLabel.setVisible(true);
                });
            }
        }).start();
    }
    
    private VBox createRoundTripCard(RoundTrip roundTrip) {
        VBox card = new VBox(15);
        card.setStyle("-fx-background-color: rgba(255,255,255,0.1); -fx-background-radius: 10; -fx-padding: 20; -fx-pref-width: 1100;");
        
        Flight outbound = roundTrip.getOutboundFlight();
        Flight returnFlight = roundTrip.getReturnFlight();
        
        if (outbound == null) {
            return card;
        }
        
        // СЕКЦИЯ "ТУДА"
        VBox outboundSection = createFlightSection(outbound, "ТУДА");
        card.getChildren().add(outboundSection);
        
        // СЕКЦИЯ "ОБРАТНО"
        if (returnFlight != null) {
            VBox returnSection = createFlightSection(returnFlight, "ОБРАТНО");
            card.getChildren().add(returnSection);
        } else {
            // Если обратного рейса нет, показываем сообщение
            VBox noReturnSection = new VBox(5);
            Label noReturnTitle = new Label("ОБРАТНО");
            noReturnTitle.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");
            Label noReturnLabel = new Label("Рейс не выбран");
            noReturnLabel.setStyle("-fx-text-fill: rgba(255,255,255,0.6); -fx-font-size: 14px; -fx-padding: 10 0;");
            noReturnSection.getChildren().addAll(noReturnTitle, noReturnLabel);
            card.getChildren().add(noReturnSection);
        }
        
        // Футер с общей стоимостью и кнопкой
        HBox footer = new HBox(20);
        footer.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        
        BigDecimal totalPrice = calculateRoundTripPrice(roundTrip);
        Label priceLabel = new Label("Общая стоимость: " + totalPrice + " ₽");
        priceLabel.setStyle("-fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;");
        
        Button selectButton = new Button("Выбрать");
        selectButton.setStyle("-fx-background-color: #ff3440; -fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10 30; -fx-background-radius: 5;");
        selectButton.setOnAction(e -> handleSelectRoundTrip(roundTrip));
        
        footer.getChildren().addAll(priceLabel, selectButton);
        card.getChildren().add(footer);
        
        return card;
    }
    
    private VBox createFlightSection(Flight flight, String sectionTitle) {
        VBox section = new VBox(10);
        
        // Заголовок секции
        Label sectionLabel = new Label(sectionTitle);
        sectionLabel.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");
        section.getChildren().add(sectionLabel);
        
        // Авиакомпания и номер рейса
        Label airlineLabel = new Label(flight.getAirlineName() + " " + flight.getFlightNumber());
        airlineLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
        section.getChildren().add(airlineLabel);
        
        // Детали рейса
        HBox details = new HBox(30);
        
        // Отправление
        VBox departureBox = new VBox(5);
        Label depTime = new Label(flight.getDepartureTime().format(timeFormatter));
        depTime.setStyle("-fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;");
        Label depDate = new Label(flight.getDepartureTime().format(dateFormatter));
        depDate.setStyle("-fx-text-fill: white; -fx-font-size: 12px;");
        Label depCity = new Label(flight.getFromCityName());
        depCity.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
        departureBox.getChildren().addAll(depTime, depDate, depCity);
        
        // Время в пути
        VBox durationBox = new VBox(5);
        long hours = flight.getDurationInHours();
        Label duration = new Label(hours + " ч");
        duration.setStyle("-fx-text-fill: white; -fx-font-size: 12px;");
        durationBox.setAlignment(javafx.geometry.Pos.CENTER);
        durationBox.getChildren().add(duration);
        
        // Прибытие
        VBox arrivalBox = new VBox(5);
        Label arrTime = new Label(flight.getArrivalTime().format(timeFormatter));
        arrTime.setStyle("-fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;");
        Label arrDate = new Label(flight.getArrivalTime().format(dateFormatter));
        arrDate.setStyle("-fx-text-fill: white; -fx-font-size: 12px;");
        Label arrCity = new Label(flight.getToCityName());
        arrCity.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");
        arrivalBox.getChildren().addAll(arrTime, arrDate, arrCity);
        
        details.getChildren().addAll(departureBox, durationBox, arrivalBox);
        section.getChildren().add(details);
        
        return section;
    }
    
    private BigDecimal calculateRoundTripPrice(RoundTrip roundTrip) {
        BigDecimal totalPrice = BigDecimal.ZERO;
        
        // Цена за рейс туда
        if (roundTrip.getOutboundFlight() != null) {
            totalPrice = totalPrice.add(calculateFlightPrice(roundTrip.getOutboundFlight()));
        }
        
        // Цена за рейс обратно
        if (roundTrip.getReturnFlight() != null) {
            totalPrice = totalPrice.add(calculateFlightPrice(roundTrip.getReturnFlight()));
        }
        
        // Дополнительный багаж (один раз для всей поездки)
        BigDecimal baggageFee = searchParams.isExtraBaggage() ? new BigDecimal("2000") : BigDecimal.ZERO;
        totalPrice = totalPrice.add(baggageFee);
        
        return totalPrice;
    }
    
    private BigDecimal calculateFlightPrice(Flight flight) {
        BigDecimal basePrice = flight.getBasePrice();
        int totalPassengers = searchParams.getTotalPassengers();
        
        // Множитель для класса обслуживания
        double classMultiplier = 1.0;
        switch (searchParams.getServiceClass()) {
            case "Премиум": classMultiplier = 1.5; break;
            case "Бизнес": classMultiplier = 2.0; break;
        }
        
        return basePrice.multiply(new BigDecimal(classMultiplier))
                .multiply(new BigDecimal(totalPassengers));
    }
    
    private void handleSelectRoundTrip(RoundTrip roundTrip) {
        if (!SessionManager.getInstance().isLoggedIn()) {
            showAuthDialog(roundTrip);
        } else {
            openBookingWindow(roundTrip);
        }
    }
    
    private void showAuthDialog(RoundTrip roundTrip) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo8/auth-view.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(loader.load());
            try {
                scene.getStylesheets().add(getClass().getResource("/com/example/demo8/styles.css").toExternalForm());
            } catch (Exception e) {}
            stage.setScene(scene);
            stage.setTitle("Вход");
            stage.setResizable(false);
            
            AuthController controller = loader.getController();
            controller.setLoginMode(true);
            controller.setSelectedRoundTrip(roundTrip);
            controller.setResultsController(this);
            
            stage.showAndWait();
        } catch (IOException e) {
            showError("Ошибка открытия окна авторизации: " + e.getMessage());
        }
    }
    
    public void openBookingWindow(RoundTrip roundTrip) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo8/booking-view.fxml"));
            Stage stage = (Stage) flightsContainer.getScene().getWindow();
            Scene scene = new Scene(loader.load());
            try {
                scene.getStylesheets().add(getClass().getResource("/com/example/demo8/styles.css").toExternalForm());
            } catch (Exception e) {}
            stage.setScene(scene);
            stage.setTitle("Бронирование");
            
            BookingController controller = loader.getController();
            controller.setRoundTrip(roundTrip);
            controller.setSearchParams(searchParams);
        } catch (IOException e) {
            showError("Ошибка открытия окна бронирования: " + e.getMessage());
        }
    }
    
    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo8/main-view.fxml"));
            Stage stage = (Stage) flightsContainer.getScene().getWindow();
            Scene scene = new Scene(loader.load());
            try {
                scene.getStylesheets().add(getClass().getResource("/com/example/demo8/styles.css").toExternalForm());
            } catch (Exception e) {}
            stage.setScene(scene);
            stage.setTitle("Поиск авиабилетов");
        } catch (IOException e) {
            showError("Ошибка возврата: " + e.getMessage());
        }
    }
    
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

