package com.example.demo8.controllers;

import com.example.demo8.models.City;
import com.example.demo8.models.SearchParams;
import com.example.demo8.services.SupabaseClient;
import com.example.demo8.utils.SessionManager;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

public class MainController {
    @FXML private ComboBox<City> fromCityCombo;
    @FXML private ComboBox<City> toCityCombo;
    @FXML private DatePicker departureDatePicker;
    @FXML private DatePicker returnDatePicker;
    @FXML private Button passengersButton;
    @FXML private CheckBox extraBaggageCheck;
    @FXML private Button loginButton;
    @FXML private Button registerButton;
    @FXML private Button profileButton;
    
    private SupabaseClient supabaseClient;
    private SearchParams searchParams;
    private ObservableList<City> cities;
    
    public void initialize() {
        supabaseClient = new SupabaseClient();
        searchParams = new SearchParams();
        cities = FXCollections.observableArrayList();
        
        // Установка минимальной даты
        departureDatePicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(empty || date.isBefore(LocalDate.now()));
            }
        });
        
        returnDatePicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                LocalDate departureDate = departureDatePicker.getValue();
                setDisable(empty || (departureDate != null && date.isBefore(departureDate)));
            }
        });
        
        departureDatePicker.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && returnDatePicker.getValue() != null && returnDatePicker.getValue().isBefore(newVal)) {
                returnDatePicker.setValue(null);
            }
        });
        
        loadCities();
        updateUI();
    }
    
    private void loadCities() {
        new Thread(() -> {
            try {
                List<City> cityList = supabaseClient.getCities();
                Platform.runLater(() -> {
                    cities.setAll(cityList);
                    fromCityCombo.setItems(cities);
                    toCityCombo.setItems(cities);
                });
            } catch (IOException e) {
                Platform.runLater(() -> {
                    showError("Ошибка загрузки городов: " + e.getMessage());
                });
            }
        }).start();
    }
    
    @FXML
    private void handlePassengers() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo8/passengers-view.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(loader.load());
            try {
                scene.getStylesheets().add(getClass().getResource("/com/example/demo8/styles.css").toExternalForm());
            } catch (Exception e) {}
            stage.setScene(scene);
            stage.setTitle("Выбор пассажиров");
            stage.setResizable(false);
            
            PassengersController controller = loader.getController();
            if (controller != null) {
                controller.setSearchParams(searchParams);
                controller.setMainController(this);
            }
            
            stage.showAndWait();
            updatePassengersButton();
        } catch (IOException e) {
            e.printStackTrace();
            showError("Ошибка открытия окна выбора пассажиров: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            showError("Неожиданная ошибка: " + e.getMessage());
        }
    }
    
    @FXML
    private void handleSearch() {
        if (fromCityCombo.getValue() == null) {
            showError("Выберите город отправления");
            return;
        }
        if (toCityCombo.getValue() == null) {
            showError("Выберите город назначения");
            return;
        }
        if (departureDatePicker.getValue() == null) {
            showError("Выберите дату вылета");
            return;
        }
        if (fromCityCombo.getValue().getId().equals(toCityCombo.getValue().getId())) {
            showError("Города отправления и назначения должны отличаться");
            return;
        }
        
        searchParams.setFromCity(fromCityCombo.getValue());
        searchParams.setToCity(toCityCombo.getValue());
        searchParams.setDepartureDate(departureDatePicker.getValue());
        searchParams.setReturnDate(returnDatePicker.getValue());
        searchParams.setExtraBaggage(extraBaggageCheck.isSelected());
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo8/results-view.fxml"));
            Stage stage = (Stage) fromCityCombo.getScene().getWindow();
            Scene scene = new Scene(loader.load());
            try {
                scene.getStylesheets().add(getClass().getResource("/com/example/demo8/styles.css").toExternalForm());
            } catch (Exception e) {}
            stage.setScene(scene);
            stage.setTitle("Результаты поиска");
            
            ResultsController controller = loader.getController();
            controller.setSearchParams(searchParams);
            controller.loadFlights();
        } catch (IOException e) {
            showError("Ошибка открытия результатов поиска: " + e.getMessage());
        }
    }
    
    @FXML
    private void handleLogin() {
        showAuthDialog(true);
    }
    
    @FXML
    private void handleRegister() {
        showAuthDialog(false);
    }
    
    @FXML
    private void handleProfile() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo8/profile-view.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(loader.load());
            try {
                scene.getStylesheets().add(getClass().getResource("/com/example/demo8/styles.css").toExternalForm());
            } catch (Exception e) {}
            stage.setScene(scene);
            stage.setTitle("Личный кабинет");
            stage.show();
        } catch (IOException e) {
            showError("Ошибка открытия личного кабинета: " + e.getMessage());
        }
    }
    
    private void showAuthDialog(boolean isLogin) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo8/auth-view.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(loader.load());
            try {
                scene.getStylesheets().add(getClass().getResource("/com/example/demo8/styles.css").toExternalForm());
            } catch (Exception e) {}
            stage.setScene(scene);
            stage.setTitle(isLogin ? "Вход" : "Регистрация");
            stage.setResizable(false);
            
            AuthController controller = loader.getController();
            controller.setLoginMode(isLogin);
            controller.setMainController(this);
            
            stage.showAndWait();
            updateUI();
        } catch (IOException e) {
            showError("Ошибка открытия окна авторизации: " + e.getMessage());
        }
    }
    
    public void updatePassengersButton() {
        int total = searchParams.getTotalPassengers();
        String text = total + " " + getPassengerWord(total) + ", " + searchParams.getServiceClass();
        passengersButton.setText(text);
    }
    
    private String getPassengerWord(int count) {
        if (count % 10 == 1 && count % 100 != 11) return "пассажир";
        if (count % 10 >= 2 && count % 10 <= 4 && (count % 100 < 10 || count % 100 >= 20)) return "пассажира";
        return "пассажиров";
    }
    
    public void updateUI() {
        boolean loggedIn = SessionManager.getInstance().isLoggedIn();
        loginButton.setVisible(!loggedIn);
        registerButton.setVisible(!loggedIn);
        profileButton.setVisible(loggedIn);
    }
    
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    public SearchParams getSearchParams() {
        return searchParams;
    }
}

