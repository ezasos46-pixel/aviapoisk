module com.example.demo8 {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires okhttp3;

    opens com.example.demo8 to javafx.fxml;
    opens com.example.demo8.models to com.google.gson;
    opens com.example.demo8.controllers to javafx.fxml;
    exports com.example.demo8;
    exports com.example.demo8.controllers;
    exports com.example.demo8.models;
}